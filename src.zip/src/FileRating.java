import java.util.HashMap;

public class FileRating {
    HashMap<Integer, Integer> wordMap;
    int movieRating;
    FileRating(){
        wordMap = new HashMap<Integer, Integer>();
    }
}
